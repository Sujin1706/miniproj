﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BAL;
using Entity;
using Exception;

namespace eShoppy
{
    class Program
    {
        public static List<Customer> customers = new List<Customer>();     
        public static void AddCustomer()
        {
            Customer customer = new Customer();
            try
            {
                Console.Write("Enter Customer ID : ");
                customer.CustomerId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Organization Name : ");
                customer.OrganizationName = Console.ReadLine();

                Console.Write("Enter Contact Person : ");
                customer.ContactPerson = Console.ReadLine();

                Console.Write("Enter Contact No : ");
                customer.ContactNumber = Console.ReadLine();

                Console.Write("Enter Delivery Address : ");
                customer.DeliveryAddress = Console.ReadLine();

                Console.Write("Enter Official Email : ");
                customer.OfficialEmail = Console.ReadLine();

                bool customerAdded = Bal.AddCustomer(customer);
                if (customerAdded)
                {
                    Console.WriteLine("Customer Added Successfully");
                }
                else

                    throw new CustomerException("Customer Details not Added");
            }
            catch (CustomerException ce)
            {

                Console.WriteLine(ce.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateCustomer()
        {
            Customer customer = new Customer();
            try
            {
                Console.Write("Enter Customer Id to be Updated : ");
                customer.CustomerId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Organization Name to be Updated : ");
                customer.OrganizationName = Console.ReadLine();
                Console.Write("Enter Contact Person to be Updated: ");
                customer.ContactPerson = Console.ReadLine();
                Console.Write("Enter Contact No to be Updated: ");
                customer.ContactNumber = Console.ReadLine();
                Console.Write("Enter Delivery Address : ");
                customer.DeliveryAddress = Console.ReadLine();
                Console.Write("Enter Official Email : ");
                customer.OfficialEmail = Console.ReadLine();
                bool customerUpdated = Bal.UpdateCustomer(customer);
                if (customerUpdated)
                {
                    Console.WriteLine("Customer Updated Successfully");
                }
                else
                    throw new CustomerException("Customer Details not Updated");
            }
            catch (CustomerException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteCustomer()
        {
            int id;
            try
            {
                Console.Write("Enter Customer ID to be Deleted : ");
                id = Convert.ToInt32(Console.ReadLine());
                bool customerdeleted = Bal.DeleteCustomer(id);
                if (customerdeleted)
                {
                    Console.WriteLine("Customer Deleted Successfully");
                }
                else
                    throw new CustomerException("Customer not deleted");
            }
            catch (CustomerException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchCustomer()
        {
            int id;
            Customer customer = null;
            try
            {
                Console.Write("Enter Customer ID to be Searched : ");
                id = Convert.ToInt32(Console.ReadLine());
                customer = Bal.SearchCustomer(id);
                if (customer != null)
                {
                    Console.WriteLine("Customer ID : " + customer.CustomerId);
                    Console.WriteLine("Organization Name : " + customer.OrganizationName);
                    Console.WriteLine("Contact Person : " + customer.ContactPerson);
                    Console.WriteLine("Contact Number : " + customer.ContactNumber);
                    Console.WriteLine("Delivery Address : " + customer.DeliveryAddress);
                    Console.WriteLine("Official Email : " + customer.OfficialEmail);
                }
                else
                    throw new CustomerException("Customer not found");
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void RetrieveCustomer()
        {
            try
            {
                List<Customer> customerList = Bal.RetrieveCustomer();
                if (customerList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Customer ID    Organization Name   Contact Person Contact No  Delivery Address  Official Email ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Customer customer in customerList)
                    {
                        Console.WriteLine($"{customer.CustomerId} \t {customer.OrganizationName} \t {customer.ContactPerson} \t {customer.ContactNumber} \t {customer.DeliveryAddress}  \t {customer.OfficialEmail} ");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomerException("Customer Details not Available");
                }
            }
            catch (CustomerException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeCustomer()
        {
            try
            {
                bool customerSerialized = Bal.SerializeCustomer();
                if (customerSerialized)
                {
                    Console.WriteLine("Customer details serialized successfully");
                }
                else
                {
                    throw new CustomerException("Customer Details not Serialized");
                }
            }
            catch (CustomerException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeCustomer()
        {
            try
            {
                List<Customer> customerList = Bal.DeserializeCustomer();
                if (customerList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Customer ID    Organization Name   Contact Person   Contact No  Delivery Address  Official Email  ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Customer customer in customerList)
                    {
                        Console.WriteLine($"{customer.CustomerId} \t {customer.OrganizationName} \t {customer.ContactPerson} \t {customer.ContactNumber} \t {customer.DeliveryAddress} \t   \t {customer.OfficialEmail} ");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomerException("Customer Details not Deserialized");
                }
            }
            catch (CustomerException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Customer Menu***********");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. Update Customer");
            Console.WriteLine("3. Delete Customer");
            Console.WriteLine("4. Search Customer");
            Console.WriteLine("5. Retrieve Customer");
            Console.WriteLine("6. Serialize Customer");
            Console.WriteLine("7. Deserialize Customer");
            Console.WriteLine("8. Exit");
            Console.WriteLine("**************************");
        }
    


        public static List<Dealer> dealers = new List<Dealer>();
        public static void AddDealer()
        {
            Dealer deal = new Dealer();
            try
            {
                Console.Write("Enter Dealer code : ");
                deal.DealerCode = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Organization Name : ");
                deal.OrganizationName = Console.ReadLine();

                Console.Write("Enter Contact Person : ");
                deal.ContactPerson = Console.ReadLine();

                Console.Write("Enter Contact No : ");
                deal.ContactNumber = Console.ReadLine();

                Console.Write("Enter Delivery Address : ");
                deal.DeliveryAddress = Console.ReadLine();

                Console.Write("Enter Warehouse Address : ");
                deal.WarehouseAddress = Console.ReadLine();

                Console.Write("Enter Official Email : ");
                deal.OfficialEmail = Console.ReadLine();

                bool dealAdded = Bal.AddDealer(deal);
                if (dealAdded)
                {
                    Console.WriteLine("Dealer Added Successfully");
                }
                else

                    throw new DealerException("Dealer Details not Added");
            }
            catch (DealerException ce)
            {

                Console.WriteLine(ce.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void UpdateDealer()
        {
            Dealer deal = new Dealer();
            try
            {
                Console.Write("Enter Dealer code to be Updated : ");
                deal.DealerCode = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Organization Name to be Updated : ");
                deal.OrganizationName = Console.ReadLine();
                Console.Write("Enter Contact Person to be Updated: ");
                deal.ContactPerson = Console.ReadLine();
                Console.Write("Enter Contact No to be Updated: ");
                deal.ContactNumber = Console.ReadLine();
                Console.Write("Enter Delivery Address : ");
                deal.DeliveryAddress = Console.ReadLine();
                Console.Write("Enter Warehouse Address : ");
                deal.WarehouseAddress = Console.ReadLine();
                Console.Write("Enter Official Email : ");
                deal.OfficialEmail = Console.ReadLine();

                bool dealUpdated = Bal.UpdateDealer(deal);
                if (dealUpdated)
                {
                    Console.WriteLine("Dealer Updated Successfully");
                }
                else
                    throw new DealerException("Dealer Details not Updated");
            }
            catch (DealerException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeleteDealer()
        {
            int id;
            try
            {
                Console.Write("Enter Dealer ID to be Deleted : ");
                id = Convert.ToInt32(Console.ReadLine());
                bool dealdeleted = Bal.DeleteDealer(id);
                if (dealdeleted)
                {
                    Console.WriteLine("Dealer Deleted Successfully");
                }
                else
                    throw new DealerException("Dealer not deleted");
            }
            catch (DealerException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SearchDealer()
        {
            int id;
            Dealer deal = null;
            try
            {
                Console.Write("Enter Dealer ID to be Searched : ");
                id = Convert.ToInt32(Console.ReadLine());
                deal = Bal.SearchDealer(id);
                if (deal != null)
                {
                    Console.WriteLine("Dealer Code : " + deal.DealerCode);
                    Console.WriteLine("Organization Name : " + deal.OrganizationName);
                    Console.WriteLine("Contact Person : " + deal.ContactPerson);
                    Console.WriteLine("Contact Number : " + deal.ContactNumber);
                    Console.WriteLine("Delivery Address : " + deal.DeliveryAddress);
                    Console.WriteLine("Warehouse Address : " + deal.WarehouseAddress);
                    Console.WriteLine("Official Email : " + deal.OfficialEmail);

                }
                else
                    throw new DealerException("Dealer not found");
            }
            catch (DealerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void RetrieveDealer()
        {
            try
            {
                List<Dealer> dealList = Bal.RetrieveDealer();
                if (dealList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Dealer Code    Organization Name   Contact Person  Contact No  Delivery Address   Address Warehouse   Official Email  ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Dealer deal in dealList)
                    {
                        Console.WriteLine($"{deal.DealerCode} \t {deal.OrganizationName} \t {deal.ContactPerson} \t {deal.ContactNumber} \t {deal.DeliveryAddress}  \t { deal.WarehouseAddress} \t {deal.OfficialEmail} ");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new DealerException("Dealer Details not Available");
                }
            }
            catch (DealerException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SerializeDealer()
        {
            try
            {
                bool dealSerialized = Bal.SerializeDealer();
                if (dealSerialized)
                {
                    Console.WriteLine("Dealer details serialized successfully");
                }
                else
                {
                    throw new CustomerException("Dealer Details not Serialized");
                }
            }
            catch (DealerException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeserializeDealer()
        {
            try
            {
                List<Dealer> dealList = Bal.DeserializeDealer();
                if (dealList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Dealer Code    Organization Name   Contact Person   Contact No  Delivery Address Warehouse Address Official Email  ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Dealer deal in dealList)
                    {
                        Console.WriteLine($"{deal.DealerCode}\t{deal.OrganizationName}\t{deal.ContactPerson}\t {deal.ContactNumber}\t {deal.DeliveryAddress}\t{deal.WarehouseAddress}\t{deal.OfficialEmail}");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new DealerException("Dealer Details not Deserialized");
                }
            }
            catch (DealerException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void PrintMenuDealer()
        {
            Console.WriteLine("\n***********Dealer Menu***********");
            Console.WriteLine("1. Add Dealer");
            Console.WriteLine("2. Update Dealer");
            Console.WriteLine("3. Delete Dealer");
            Console.WriteLine("4. Search Dealer");
            Console.WriteLine("5. Retrieve Dealer");
            Console.WriteLine("6. Serialize Dealer");
            Console.WriteLine("7. Deserialize Dealer");
            Console.WriteLine("8. Exit");
            Console.WriteLine("**************************");
        }
    


        public static List<Product> products = new List<Product>();
        public static void AddProduct()
        {
            Product prod = new Product();
            try
            {
                Console.Write("Enter Product ID : ");
                prod.ProductId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Product Name : ");
                prod.ProductName = Console.ReadLine();

                Console.Write("Enter Quantity : ");
                prod.Quantity = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Price: ");
                prod.Price = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Date and Time of Product Added : ");
                prod.DateandTimeofProductAdded = Convert.ToDateTime(Console.ReadLine());

                bool prodAdded = Bal.AddProduct(prod);
                if (prodAdded)
                {
                    Console.WriteLine("Product Added Successfully");
                }
                else

                    throw new ProductException("Product Details not Added");
            }
            catch (ProductException ce)
            {

                Console.WriteLine(ce.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void UpdateProduct()
        {
            Product prod = new Product();
            try
            {
                Console.Write("Enter Product ID to be Updated : ");
                prod.ProductId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Product Name to be Updated : ");
                prod.ProductName = Console.ReadLine();
                Console.Write("Enter Quantity to be Updated: ");
                prod.Quantity = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Price to be Updated: ");
                prod.Price = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Date and Time of Product Added : ");
                prod.DateandTimeofProductAdded = Convert.ToDateTime(Console.ReadLine());

                bool prodUpdated = Bal.UpdateProduct(prod);
                if (prodUpdated)
                {
                    Console.WriteLine("Product Updated Successfully");
                }
                else
                    throw new ProductException("Product Details not Updated");
            }
            catch (ProductException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeleteProduct()
        {
            int id;
            try
            {
                Console.Write("Enter Product ID to be Deleted : ");
                id = Convert.ToInt32(Console.ReadLine());
                bool proddeleted = Bal.DeleteProduct(id);
                if (proddeleted)
                {
                    Console.WriteLine("Product Deleted Successfully");
                }
                else
                    throw new ProductException("Product not deleted");
            }
            catch (ProductException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SearchProduct()
        {
            int id;
            Product prod = null;
            try
            {
                Console.Write("Enter Product ID to be Searched : ");
                id = Convert.ToInt32(Console.ReadLine());
                prod = Bal.SearchProduct(id);
                if (prod != null)
                {
                    Console.WriteLine("Product ID : " + prod.ProductId);
                    Console.WriteLine("Product Name : " + prod.ProductName);
                    Console.WriteLine("Quantity : " + prod.Quantity);
                    Console.WriteLine("Price: " + prod.Price);
                    Console.WriteLine("DateTime : " + prod.DateandTimeofProductAdded);
                }
                else
                    throw new ProductException("Product not found");
            }
            catch (ProductException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void RetrieveProduct()
        {
            try
            {
                List<Product> prodList = Bal.RetrieveProduct();
                if (prodList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Product ID    Product Name   Quantity Price  DateandTimeofProductAdded   ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Product prod in prodList)
                    {
                        Console.WriteLine($"{prod.ProductId} \t {prod.ProductName} \t {prod.Quantity} \t {prod.Price} \t {prod.DateandTimeofProductAdded}   ");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new ProductException("Product Details not Available");
                }
            }
            catch (ProductException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SerializeProduct()
        {
            try
            {
                bool prodSerialized = Bal.SerializeProduct();
                if (prodSerialized)
                {
                    Console.WriteLine("Product details serialized successfully");
                }
                else
                {
                    throw new ProductException("Product Details not Serialized");
                }
            }
            catch (ProductException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeserializeProduct()
        {
            try
            {
                List<Product> prodList = Bal.DeserializeProduct();
                if (prodList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Product ID    Product Name   Quantity   Price  DateandTimeofProductAdded  ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Product prod in prodList)
                    {
                        Console.WriteLine($"{prod.ProductId}\t{prod.ProductName}\t{prod.Quantity}\t {prod.Price}\t {prod.DateandTimeofProductAdded}");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new ProductException("Dealer Details not Deserialized");
                }
            }
            catch (ProductException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void PrintMenuProduct()
        {
            Console.WriteLine("\n***********Product Menu***********");
            Console.WriteLine("1. Add Product");
            Console.WriteLine("2. Update Product");
            Console.WriteLine("3. Delete Product");
            Console.WriteLine("4. Search Product");
            Console.WriteLine("5. Retrieve Product");
            Console.WriteLine("6. Serialize Product");
            Console.WriteLine("7. Deserialize Product");
            Console.WriteLine("8. Exit");
            Console.WriteLine("**************************");
        }


        
        static void Main(string[] args)
        {
            Console.WriteLine("***********Login***********");
            string username = null;
            string password = null;
            Console.WriteLine("Enter Username:");
            username = Console.ReadLine();
            Console.WriteLine("Enter Password:");
            password = Console.ReadLine();
            string message = "Welcome" + username;
            if (username == "Sujin" && password == "sujin1706")
            {
                Console.WriteLine("Login successful");
            }
            else if (username == "Vishnu" && password == "vishnu1998")
            {
                Console.WriteLine("Login successful");
            }
            else if (username == "Admin" && password == "password")
            {
                Console.WriteLine("Login successful");
            }
            else
            {
                Console.WriteLine("Sorry Login is invalid!");

            }
            try
            { 
                int iSelect;
                Console.WriteLine("Choose your Option:   \nEnter 1 for Register as Customer ! \nEnter 2 for Register as Dealer ! \nEnter 3 for Registering Product! \n----------------------------------");
                iSelect = Convert.ToInt32(Console.ReadLine());               
                if (iSelect == 1)
                    PrintMenu();
                else if (iSelect == 2)
                    PrintMenuDealer();
                else if (iSelect == 3)
                    PrintMenuProduct();
                else
                    return;
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }


            int choice;
            try
            {
                do
                {
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddCustomer();
                            break;
                        case 2:
                            UpdateCustomer();
                            break;
                        case 3:
                            DeleteCustomer();
                            break;
                        case 4:
                            SearchCustomer();
                            break;
                        case 5:
                            RetrieveCustomer();
                            break;
                        case 6:
                            SerializeCustomer();
                            break;
                        case 7:
                            DeserializeCustomer();
                            break;
                        case 8:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Please make valid choice");
                            break;
                    }
                } while (choice != 8);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            int choose;
            try
            {
                do
                {
                    Console.Write("Enter your choice : ");
                    choose = Convert.ToInt32(Console.ReadLine());
                    switch (choose)
                    {
                        case 1:
                            AddDealer();
                            break;
                        case 2:
                            UpdateDealer();
                            break;
                        case 3:
                            DeleteDealer();
                            break;
                        case 4:
                            SearchDealer();
                            break;
                        case 5:
                            RetrieveDealer();
                            break;
                        case 6:
                            SerializeDealer();
                            break;
                        case 7:
                            DeserializeDealer();
                            break;
                        case 8:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Please make valid choice");
                            break;
                    }
                } while (choose != 8);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }


            int select;
            try
            {
                do
                {
                    Console.Write("Enter your choice : ");
                    select = Convert.ToInt32(Console.ReadLine());
                    switch (select)
                    {
                        case 1:
                            AddProduct();
                            break;
                        case 2:
                            UpdateProduct();
                            break;
                        case 3:
                            DeleteProduct();
                            break;
                        case 4:
                            SearchProduct();
                            break;
                        case 5:
                            RetrieveProduct();
                            break;
                        case 6:
                            SerializeProduct();
                            break;
                        case 7:
                            DeserializeProduct();
                            break;
                        case 8:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Please make valid choice");
                            break;
                    }
                }
                while (select != 8);
            }
                       
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
    }
    




