﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Entity;
using Exception;
using System.Text.RegularExpressions;

namespace BAL
{
    public class Bal
    {
      
        private static bool Validate(Customer customer)
        {
            bool Valid = true;
            StringBuilder errorMessages = new StringBuilder();

            bool isUsername = Regex.IsMatch(customer.Username, "^[a-zA-Z0-9]*$");
            if (!isUsername)
            {
                errorMessages.Append("\nUsername must contain string!");
            }
            bool isPassword = Regex.IsMatch(customer.Password, "^[a-zA-Z0-9]*$");
            if (!isPassword)
            {
                errorMessages.Append("\nPassword must contain integer!");
            }
            bool isCustomerId = Regex.IsMatch(customer.CustomerId.ToString(), "^[0-9]{1,5}$");
            if (!isCustomerId)
            {
                errorMessages.Append("Customer ID must contain not more than 5 digits!");
                Valid = false;
            }
            //bool isName = Regex.IsMatch(customer.OrganizationName, "^[A-Z][a-z]");
            //if (!isName)
            //{
            //    errorMessages.Append(Environment.NewLine + "Organization Name Should Start with Capital Letter");
            //    Valid = false;
            //}
            //bool isContactPersonName = Regex.IsMatch(customer.ContactPerson, "^[A-Z][a-z]");
            //if (!isContactPersonName)
            //{
            //    Valid = false;
            //    errorMessages.Append(Environment.NewLine + "Name Should Start with Capital Letter!");
            //}
            bool isContactNo = Regex.IsMatch(customer.ContactNumber.ToString(), "^[0-9]{10}$");
            if (!isContactNo)
            {
                Valid = false;
                errorMessages.Append("Contact No must be of 10 digits!");
            }
            //bool isDeliveryAddress = Regex.IsMatch(customer.DeliveryAddress, "^[A-Z][a-z]");
            //if (!isDeliveryAddress)
            //{
            //    errorMessages.Append(Environment.NewLine + "Address Should start with Capital Letter");
            //    Valid = false;
            //}
            bool isOfficialEmail = Regex.IsMatch(customer.OfficialEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!isOfficialEmail)
            {
                errorMessages.Append("Email is Invalid!" + Environment.NewLine);
                Valid = false;
            }
            if (!Valid) { throw new CustomerException(errorMessages.ToString()); }
            return Valid;
        }


        public static bool AddCustomer(Customer customer)
        {
            bool customerAdded = false;
            try
            {
                if (Validate(customer))
                {
                    Dal Dal = new Dal();
                    customerAdded = Dal.AddCustomer(customer);
                    customerAdded = true;
                }
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerAdded;
        }

        public static bool UpdateCustomer(Customer customer)
        {
            bool customerUpdated = false;
            try
            {
                if (Validate(customer))
                {
                    Dal Dal = new Dal();
                    customerUpdated = Dal.UpdateCustomer(customer);
                    customerUpdated = true;
                }
                else
                    throw new CustomerException("Please provide valid Customer details for update");
            }
            catch (CustomerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerUpdated;
        }

        public static bool DeleteCustomer(int CustId)
        {
            bool customerDeleted = false;
            try
            {
                Dal Dal = new Dal();
                customerDeleted = Dal.DeleteCustomer(CustId);
                customerDeleted = true;
            }
            catch (CustomerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerDeleted;
        }

        public static Customer SearchCustomer(int CustId)
        {
            Customer customer = null;
            try
            {
                Dal Dal = new Dal();
                customer = Dal.SearchCustomer(CustId);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customer;
        }

        public static List<Customer> RetrieveCustomer()
        {
            List<Customer> customerList = null;
            try
            {
                customerList = Dal.RetrieveCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerList;
        }

        public static bool SerializeCustomer()
        {
            bool customerSerialized = false;
            try
            {
                customerSerialized = Dal.SerializeCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerSerialized;
        }


        public static List<Customer> DeserializeCustomer()
        {
            List<Customer> customerList = null;
            try
            {
                customerList = Dal.DeSerializeCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerList;
        }

        private static bool Validate(Dealer deal)
        {
            bool Valid = true;
            StringBuilder errorMessages = new StringBuilder();
            bool isUsername = Regex.IsMatch(deal.Username, "^[a-zA-Z0-9]*$");
            if (!isUsername)
            {
                errorMessages.Append("Username must contain string!");
            }
            bool isPassword = Regex.IsMatch(deal.Password, "^[a-zA-Z0-9]*$");
            if (!isPassword)
            {
                errorMessages.Append("Password must contain integer!");
            }
            bool isDealerCode = Regex.IsMatch(deal.DealerCode.ToString(), "^[0-9]{1,5}$");
            if (!isDealerCode)
            {
                errorMessages.Append("Dealer code must contain not more than 5 digits!");
                Valid = false;
            }
            //bool isOrganizationName = Regex.IsMatch(deal.OrganizationName, "^[A-Z][a-z]");
            //if (!isOrganizationName)
            //{
            //    errorMessages.Append(Environment.NewLine + "Organization Name Should Start with Capital Letter");
            //    Valid = false;
            //}
            //bool isContactPerson = Regex.IsMatch(deal.ContactPerson, "^[A-Z][a-z]");
            //if (!isContactPerson)
            //{
            //    Valid = false;
            //    errorMessages.Append(Environment.NewLine + "Name Should Start with Capital Letter!");
            //}
            bool isContactNo = Regex.IsMatch(deal.ContactNumber.ToString(), "^[0-9]{10}$");
            if (!isContactNo)
            {
                Valid = false;
                errorMessages.Append("Contact No must be of 10 digits!");
            }
            //bool isDeliveryAddress = Regex.IsMatch(deal.DeliveryAddress, "^[A-Z][a-z]");
            //if (!isDeliveryAddress)
            //{
            //    errorMessages.Append(Environment.NewLine + "Address Should start with Capital Letter");
            //    Valid = false;
            //}
            //    bool isWarehouseAddress = Regex.IsMatch(deal.WarehouseAddress, "^[A-Z][a-z]");
            //    if (!isWarehouseAddress)
            //    {
            //        errorMessages.Append(Environment.NewLine + "Address Should start with Capital Letter");
            //        Valid = false;
            //    }
            bool isOfficialEmail = Regex.IsMatch(deal.OfficialEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!isOfficialEmail)
            {
                errorMessages.Append("Email is Invalid!" + Environment.NewLine);
                Valid = false;
            }
            if (!Valid) { throw new DealerException(errorMessages.ToString()); }
            return Valid;
        }
        public static bool AddDealer(Dealer deal)
        {
            bool dealAdded = false;
            try
            {
                if (Validate(deal))
                {
                    Dal Dal = new Dal();
                    dealAdded = Dal.AddDealer(deal);
                    dealAdded = true;
                }
            }
            catch (DealerException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dealAdded;
        }
        public static bool UpdateDealer(Dealer deal)
        {
            bool dealUpdated = false;
            try
            {
                if (Validate(deal))
                {
                    Dal Dal = new Dal();
                    dealUpdated = Dal.UpdateDealer(deal);
                    dealUpdated = true;
                }
                else
                    throw new DealerException("Please provide valid Dealer details for update");
            }
            catch (DealerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dealUpdated;
        }
        public static bool DeleteDealer(int DealId)
        {
            bool dealDeleted = false;
            try
            {
                Dal Dal = new Dal();
                dealDeleted = Dal.DeleteDealer(DealId);
                dealDeleted = true;
            }
            catch (DealerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dealDeleted;
        }
        public static Dealer SearchDealer(int DealId)
        {
            Dealer deal = null;
            try
            {
                Dal Dal = new Dal();
                deal = Dal.SearchDealer(DealId);
            }
            catch (DealerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return deal;
        }
        public static List<Dealer> RetrieveDealer()
        {
            List<Dealer> dealList = null;
            try
            {
                dealList = Dal.RetrieveDealer();
            }
            catch (DealerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dealList;
        }
        public static bool SerializeDealer()
        {
            bool dealSerialized = false;
            try
            {
                dealSerialized = Dal.SerializeDealer();
            }
            catch (DealerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dealSerialized;
        }
        public static List<Dealer> DeserializeDealer()
        {
            List<Dealer> dealList = null;
            try
            {
                dealList = Dal.DeSerializeDealer();
            }
            catch (DealerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dealList;
        }


        private static bool Validate(Product prod)
        {
            bool Valid = true;
            StringBuilder errorMessages = new StringBuilder();
            bool isProductId = Regex.IsMatch(prod.ProductId.ToString(), "^[0-9]{1,5}$");
            if (!isProductId)
            {
                errorMessages.Append("Product ID must contain not more than 5 digits!");
                Valid = false;
            }
            //bool isProductName = Regex.IsMatch(prod.ProductName, "^[A-Z][a-z]");
            //if (!isProductName)
            //{
            //    errorMessages.Append(Environment.NewLine + "Product Name Should Start with Capital Letter");
            //    Valid = false;
            //}
            bool isQuantity = Regex.IsMatch(prod.Quantity.ToString(), "^[0-9]$");
            if (!isQuantity)
            {
                Valid = false;
                errorMessages.Append(Environment.NewLine + "Quantity must be integer!");
            }
            bool isPrice = Regex.IsMatch(prod.Price.ToString(), "^[0-9]$");
            if (!isPrice)
            {
                Valid = false;
                errorMessages.Append("Price must be integer!");
            }
            if (prod.DateandTimeofProductAdded >= DateTime.Now.Date)
            {
                Valid = false;
                errorMessages.Append("Date time must be given properly!");
            }

            if (!Valid) { throw new ProductException(errorMessages.ToString()); }
            return Valid;
        }
        public static bool AddProduct(Product prod)
        {
            bool prodAdded = false;
            try
            {
                if (Validate(prod))
                {
                    Dal Dal = new Dal();
                    prodAdded = Dal.AddProduct(prod);
                    prodAdded = true;
                }
            }
            catch (ProductException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prodAdded;
        }
        public static bool UpdateProduct(Product prod)
        {
            bool prodUpdated = false;
            try
            {
                if (Validate(prod))
                {
                    Dal Dal = new Dal();
                    prodUpdated = Dal.UpdateProduct(prod);
                    prodUpdated = true;
                }
                else
                    throw new ProductException("Please provide valid Product details for update");
            }
            catch (ProductException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prodUpdated;
        }
        public static bool DeleteProduct(int ProdId)
        {
            bool prodDeleted = false;
            try
            {
                Dal Dal = new Dal();
                prodDeleted = Dal.DeleteProduct(ProdId);
                prodDeleted = true;
            }
            catch (ProductException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prodDeleted;
        }
        public static Product SearchProduct(int ProdId)
        {
            Product prod = null;
            try
            {
                Dal Dal = new Dal();
                prod = Dal.SearchProduct(ProdId);
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prod;
        }
        public static List<Product> RetrieveProduct()
        {
            List<Product> prodList = null;
            try
            {
                prodList = Dal.RetrieveProduct();
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prodList;
        }
        public static bool SerializeProduct()
        {
            bool prodSerialized = false;
            try
            {
                prodSerialized = Dal.SerializeProduct();
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prodSerialized;
        }
        public static List<Product> DeserializeProduct()
        {
            List<Product> prodList = null;
            try
            {
                prodList = Dal.DeSerializeProduct();
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prodList;
        }
    }
}

//        public Login(string user, string pass)
//        {
//            this.Username = user;
//            this.Userpassword = pass;
//        }

//        bool StringValidator(string input)
//        {
//            string pattern = "[^a-zA-Z]";
//            if (Regex.IsMatch(input, pattern))
//            {
//                return true;
//            }
//            else
//            {
//                return false;
//            }
//        }
//        bool IntegerValidator(string input)
//        {
//            string pattern = "[^0-9]";
//            if (Regex.IsMatch(input, pattern))
//            {
//                return true;
//            }
//            else
//            {
//                return false;
//            }
//        }
//        public void ClearTexts(string user, string pass)
//        {
//            user = String.Empty;
//            pass = String.Empty;
//        }
//        bool IsLoggedIn(string user, string pass)
//        {

//            if (string.IsNullOrEmpty(user))
//            {
//                errorMessages.Append("Enter the user name!");
//                return false;

//            }

//            else if (StringValidator(user) == true)
//            {
//                errorMessages.Append("Enter only text here");
//                ClearTexts(user, pass);
//                return false;
//            }

//            else
//            {
//                if (Username != user)
//                {
//                    errorMessages.Append("User name is incorrect!");
//                    ClearTexts(user, pass);
//                    return false;
//                }

//                else
//                {
//                    if (string.IsNullOrEmpty(pass))
//                    {
//                        errorMessages.Append("Enter the passowrd!");
//                        return false;
//                    }

//                    else if (IntegerValidator(pass) == true)
//                    {
//                        errorMessages.Append("Enter only integer here");
//                        return false;
//                    }

//                    else if (Userpassword != pass)
//                    {
//                        errorMessages.Append("Password is incorrect");
//                        return false;
//                    }
//                    else
//                    {
//                        return true;
//                    }
//                }
//            }
//        }
//    }
//}

